package com.prudential;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;



//@RunWith(SpringRunner.class)
//@ContextConfiguration(classes = { JUnitCoreConfiguration.class })
public class AppTest {
	
	
	@Test
	public void test() throws Exception {
		
	/*	Thread.sleep(5 * 60 * 1000);*/
	}
	

}
