/**
 * ADauthUserServiceImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.prubsn.adservice._interface.xsd;

public interface ADauthUserServiceImplService extends javax.xml.rpc.Service {
    public java.lang.String getadauthuserserviceimplPortAddress();

    public com.prubsn.adservice._interface.xsd.Adauthuserserviceimpl getadauthuserserviceimplPort() throws javax.xml.rpc.ServiceException;

    public com.prubsn.adservice._interface.xsd.Adauthuserserviceimpl getadauthuserserviceimplPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
