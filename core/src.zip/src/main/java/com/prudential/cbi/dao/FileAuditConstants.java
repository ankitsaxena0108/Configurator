package com.prudential.cbi.dao;

public class FileAuditConstants {
	
	public void getFileAuditConstants(){};

	public static final String SYSTEM_NAME = "name";

	public static final String FILE_DIRECTION = "fileDirection";

	public static final String FILE_CATEGORY = "category";

	public static final String FILE_STATUS = "status";

	public static final String PAYMENT_TYPE = "paymentType";

	public static final String FROM_DATE = "fromDate";

	public static final String TO_DATE = "toDate";

}
