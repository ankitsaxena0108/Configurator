package com.prudential.cbi.dao;

public class BankTnxConstants {

	
	public void getBankTnxConstants(){};

	public static final String BANK_CODE = "bankCode";

	public static final String FROM_POLICY = "policyStartRange";

	public static final String TO_POLICY = "policyEndRange";

	public static final String BANK_STATE = "state";

	public static final String FROM_DATE = "fromDate";

	public static final String TO_DATE = "toDate";
	
	public static final String RESPONSE_CODE = "responseCode";
}
