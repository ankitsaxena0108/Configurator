package com.prudential.core.common.locale;

public interface LocaleService {

	public Locale currentLocale();
}
