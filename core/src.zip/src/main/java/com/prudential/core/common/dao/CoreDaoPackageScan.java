package com.prudential.core.common.dao;

/**
 * Helper class to scan Agency Package Configuration.
 */
public final class CoreDaoPackageScan {
    private CoreDaoPackageScan() {}
}
