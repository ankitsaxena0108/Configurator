package com.prudential.core.cbi;

/**
 * Helper class to scan Agency Package Configuration.
 */
public final class CoreCommonBankingScan {
    private CoreCommonBankingScan() {}
}
