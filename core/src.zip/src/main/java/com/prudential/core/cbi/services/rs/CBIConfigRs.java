package com.prudential.core.cbi.services.rs;

public class CBIConfigRs {
	String cbiConfigDetails;
	String fileName;
	String category;
	String scheduleInfo;
	String otherDetails;
	public String getCbiConfigDetails() {
		return cbiConfigDetails;
	}
	public void setCbiConfigDetails(String cbiConfigDetails) {
		this.cbiConfigDetails = cbiConfigDetails;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getScheduleInfo() {
		return scheduleInfo;
	}
	public void setScheduleInfo(String scheduleInfo) {
		this.scheduleInfo = scheduleInfo;
	}
	public String getOtherDetails() {
		return otherDetails;
	}
	public void setOtherDetails(String otherDetails) {
		this.otherDetails = otherDetails;
	}

}
