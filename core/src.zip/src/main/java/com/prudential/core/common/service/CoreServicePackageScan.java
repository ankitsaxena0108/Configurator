package com.prudential.core.common.service;

/**
 * Helper class to scan Agency Package Configuration.
 */
public final class CoreServicePackageScan {
    private CoreServicePackageScan() {}
}
